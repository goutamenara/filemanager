## File manager
This is a simple package to search for files
